import "./Input.scss";

const Textarea = (props) => {
  return <textarea {...props} className="input textarea" />;
};

export default Textarea;